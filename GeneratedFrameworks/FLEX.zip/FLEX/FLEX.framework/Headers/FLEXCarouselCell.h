//
//  FLEXCarouselCell.h
//  FLEX
//
//  Created by Tanner Bennett on 7/17/19.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FLEXCarouselCell : UICollectionViewCell

@property (nonatomic, copy) NSString *title;

@end
